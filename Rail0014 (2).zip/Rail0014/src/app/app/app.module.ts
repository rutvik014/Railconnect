// app.module.ts
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';
import { AppRoutingModule } from '../app-routing.module';
import { AppComponent } from '../app.component';
import { LoginComponent } from '../login/login.component';
import { RegisterComponent } from '../register/register.component';
import { ResultsComponent } from '../results/results.component';
import { SearchComponent } from '../search/search.component';
import { BookingService } from '../services/booking.service';
import { TrainService } from '../services/train.service';
import { UserService } from '../services/user.service';
import { JourneyComponent } from '../journey/journey.component';



@NgModule({
  declarations: [
    RegisterComponent,
    LoginComponent,
    AppComponent,
    SearchComponent,
    ResultsComponent,
    JourneyComponent
     
  ],
  imports: [
    CommonModule,
    AppRoutingModule,
    HttpClientModule,
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forRoot([
      {path:'serchTrain',component:SearchComponent},
      {path:'login',component:LoginComponent},
      {path:'journey',component:JourneyComponent}
    ]), // <-- Add this line with an empty array
  ],
  providers: [
    UserService,
    TrainService,
    BookingService,
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
