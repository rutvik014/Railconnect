import { Component } from '@angular/core';
import { BookingService } from '../services/booking.service';

@Component({
  selector: 'app-journey',
  templateUrl: './journey.component.html',
  styleUrl: './journey.component.css'
})
export class JourneyComponent {
  constructor(private bookingService:BookingService){}
  
  // curJourneyData:any[];
  curJourneyData: any;

  ngOnInit() {
    // this.curJourneyData =sessionStorage.getItem('currentJourney');
    // console.log(this.curJourneyData);
    // return this.curJourneyData;

    const storedData = sessionStorage.getItem('currentJourney');
    if (storedData) {
      // Split the comma-separated string into an array
      const dataArray = storedData.split(',');

      // Map the array elements to an array of objects
      this.curJourneyData = [
        {
          BookingId: dataArray[0],
           date:dataArray[1],
          source:dataArray[2],
          destination:dataArray[3], 
          trainName:dataArray[4], 
          departureDate: dataArray[5],
          departureTime: dataArray[6], 
          cost: dataArray[7],
          passengerName: dataArray[8],
        }
      ];
    }

  }

  cancelBooking(bId:any){
    this.bookingService.deleteBooking(bId).subscribe(
        (result:any)=>{
          console.log(result);
          if(result=="Booking Cancelled"){
            alert("Booking Calcelled Successfully");
          }
        },
        (error)=>{
          console.error('something went wrong:', error)
        }
    );
  }


}



