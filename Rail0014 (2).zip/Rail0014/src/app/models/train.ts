// train.model.ts
export interface Train {
    id: number;
    trainName: string;
    source: string;
    destination: string;
    date: string;
    // Add other train-related fields as needed
  }
  