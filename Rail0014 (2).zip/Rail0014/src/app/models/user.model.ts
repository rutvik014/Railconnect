// user.model.ts
export interface User {
    username: string;
    
    // Add other properties as needed
  }
  