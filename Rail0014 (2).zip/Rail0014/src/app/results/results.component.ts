// C:\Users\rutvi\Rail0014\src\app\results\results.component.ts
import { Component, OnInit } from '@angular/core';
import { Train } from '../models/train'; // Import the Train model
import { TrainService } from '../services/train.service'; // Import the TrainService or adjust the path based on your actual structure

@Component({
  selector: 'app-results',
  styleUrls: ['./results.component.css'],
  templateUrl: './results.component.html'
})
export class ResultsComponent implements OnInit {
  trains: Train[] = [];

  constructor(private trainService: TrainService) {}

  ngOnInit() {
    // Fetch the results when the component is initialized
    this.fetchResults();
  }

  private fetchResults() {
    // Use the trainService to get the results
    this.trainService.getAllTrains().subscribe(
      (results: Train[]) => {
        this.trains = results;
      },
      (error: any) => {
        console.error('Error fetching train results:', error);
      }
    );
  }
}
