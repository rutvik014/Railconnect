// search.component.ts
import { Component } from '@angular/core';
import { Train } from '../models/train';
import { TrainService } from '../services/train.service';
import { BookingService } from '../services/booking.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent {
  source: string = '';
  destination: string = '';
  date: string = '';
  trains: Train[] = [];
  error: string | null = null;
  uId:any;
  currtId:any;
  journeyData:any;
  currentJourney:any[]=[];
  constructor(private trainService: TrainService,private bookService:BookingService,private router:Router) {}


  searchTrains() {
    this.trainService.getTrainsBySourceAndDestination(this.source, this.destination, this.date)
      .subscribe(
        (result: Train[]) => {
          this.trains = result;
          this.error = null; // Clear any previous errors
        },
        (error) => {
          this.error = 'Error fetching train results'; // Set the error message
          console.error('Error fetching train results:', error);
        }
      );
  }

  uid:any;
  getStoredUid(): any {
    this.uid= sessionStorage.getItem('uId');
    return this.uid;
  }

  getStoredCtId(): any{
    this.currtId = sessionStorage.getItem('currentTicketId');
    return this.currtId;
  } 

    bookTicket(tId:any){

      this.uid=this.getStoredUid();
      this.bookService.bookTicket(tId,this.uid).subscribe(
        (response:number) =>{
          if(response>0){
            alert("Your Ticket Booked successfully");
            this.bookService.currentBookingDetail(response).subscribe(
              (currentJourney)=>{
                const currentJourneyString = JSON.stringify(currentJourney);
                sessionStorage.setItem('currentJourney',currentJourneyString);
              }
            );
            this.router.navigate(['/journey']);
          }
        },
        (error) => { console.log(error) }
      );
  }

}
