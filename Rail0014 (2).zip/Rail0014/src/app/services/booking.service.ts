// booking.service.ts
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BookingService {
  

  constructor(private http: HttpClient) {}

  bookTicket(tId: number,uId:any): Observable<any> {
       const body ={tId,uId};
       const url=`http://localhost:8080/api/bookings/create?tId=${tId}&uId=${uId}`;
       const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
       return this.http.post(url, body, { headers,responseType:'text' });

  }

  // bookingDetail(tId: number,uId:any){
  //   const url=`http://localhost:8080/api/bookings/journey?tId=${tId}&uId=${uId}`;
  //   return this.http.get(url);
  // }

  bookingDetail(tId: number, uId: any) {
    const encodedUrl = `http://localhost:8080/api/bookings/journey?tId=${encodeURIComponent(tId)}&uId=${encodeURIComponent(uId)}`;
    return this.http.get(encodedUrl);
  }

  //currentBooking
  currentBookingDetail(bId:number) {
    const encodedUrl = `http://localhost:8080/api/bookings/currBooking?bId=${bId}`;
    return this.http.get(encodedUrl);
  }

  deleteBooking(bId:number) {
    const url = `http://localhost:8080/api/bookings/cancel/${bId}`;
    const headers = new HttpHeaders({ 'Content-Type': 'application/json',responseType:'text' });
    return this.http.delete(url,{headers,responseType:'text'});
  }

  
  // removeItem(uid:any,pid:number){
  //   const url = `http://localhost:8080/removeProductFromCart?uId=${uid}&pId=${pid}`;
  //   const headers = new HttpHeaders({ 'Content-Type': 'application/json',responseType:'text' });
    
  //   return this.http.delete(url,{headers,responseType:'text'});
  // }
  
}
