// train.service.ts
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Train } from '../models/train';

@Injectable({
  providedIn: 'root'
})
export class TrainService {
  private apiUrl = 'http://localhost:8080/api/trains';
  bookTrain: any;
  getAllTrains: any;

  constructor(private http: HttpClient) {}

  getTrainsBySourceAndDestination(source: string, destination: string, date: string): Observable<Train[]> {
    const body = {source,destination,date};
    const url = `http://localhost:8080/api/trains/search?source=${source}&destination=${destination}&date=${date}`;
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.post<Train[]>(url, body, { headers,responseType:'json'});
  } 



  // Other methods...
}
