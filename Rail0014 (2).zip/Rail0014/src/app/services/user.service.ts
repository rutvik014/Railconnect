// src/app/services/user.service.ts
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class UserService {

    private apiUrl: string = environment.apiUrl;

  constructor(private http: HttpClient) { }

  public uId:any;
  login(username: string, password: string): Observable<any> {
    const url = `http://localhost:8080/api/users/login?username=${username}&password=${password}`;  // Example login endpoint
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    this.uId= this.http.post(url,{}, { headers,responseType:'text' });
    return this.uId;
  }

  register(userDetails: { username: string, email: string, password: string }): Observable<any> {
    // For simplicity, return a mock response.
    // In a real application, you would make an HTTP request to register the user.
    const registerUrl = `${this.apiUrl}/register`;  // Example register endpoint
    return of({ success: true, message: 'Registration successful' });
  }
}
