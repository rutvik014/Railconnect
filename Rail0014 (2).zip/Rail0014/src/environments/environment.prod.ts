// src/environments/environment.prod.ts
export const environment = {
    production: true,
    apiUrl: 'https://your-production-api-url.com', // Actual API URL for production
  };
  