// environments/environment.ts
export const environment = {
    production: false,
    apiUrl: 'http://localhost:3000/api', // Example API URL for development
  };
  